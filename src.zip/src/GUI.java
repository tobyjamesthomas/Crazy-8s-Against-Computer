import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

/**
 * Created by tobyjthomas on 2015-03-25.
 */
public class GUI extends JFrame {

}
